const breeds = [ 
    'Border Collie', 
    'German Spitz', 
    'French Buldog', 
    'English Bulldog', 
    'Suberian Hysky', 
    'Corgie', 
    'Cavalier King Charles', 
    'Labrador Retriever', 
    'Golden Retriever',
];

export default breeds;