import Client from "./models/client.model.js";
import Pet from './models/pet.model.js';

await Client.sync(); 

await Pet.sync();

Pet.findAll().then(function(results) {
    for (let pet of results) {
        console.log(pet.dataValues);
    }
})

// await Client.create({name: 'Caio Di Gioia', document: '123.456.789-00'})

Client.findAll().then(function(results) {
    for (let client of results) {
        console.log(client.dataValues);
    }
})