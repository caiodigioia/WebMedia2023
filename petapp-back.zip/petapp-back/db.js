import Sequelize from "sequelize";

const dbName = 'devpet';
const dbUser = 'caiodigioia';
const dbPass = '123456';
const dbHost = '127.0.0.1';
const dbPort = 3306;

const db = new Sequelize(dbName, dbUser, dbPass, {
    dialect: 'postgres',
    host: dbHost,
    port: dbPort
});

export default db;